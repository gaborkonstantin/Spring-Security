package com.gabor.SpringSec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecApplicationTests {

	@Test
	void contextLoads() {
	}

}
